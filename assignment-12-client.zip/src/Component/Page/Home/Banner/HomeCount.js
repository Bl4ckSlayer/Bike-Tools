import React from "react";

const HomeCount = () => {
  return <div></div>;
};

export default HomeCount;
